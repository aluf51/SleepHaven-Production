import React from 'react';
import './App.css';
import AppContainer from './components/AppContainer'; // This will be created later

function App() {
  return (
    <div className="App">
      <AppContainer />
    </div>
  );
}

export default App;
